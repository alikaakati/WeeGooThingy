import {
    StyleSheet,  Dimensions
  } from 'react-native';
export default StyleSheet.create({
container:{
    flex:1,
    backgroundColor:'white',
    alignItems:'center',
    justifyContent:'center'
},
logo:{
    width:150,
    height:150
}

})