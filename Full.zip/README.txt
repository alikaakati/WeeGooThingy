Copy those folders to the asset directory and export the navigation to app js thingy
:3